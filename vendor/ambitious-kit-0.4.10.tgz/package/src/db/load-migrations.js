import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { checkedMigrations } from "../domain/migrations.js";
const SQL_FILE = /\.sql$/;
export const loadMigrations = (directory) => checkedMigrations(readdirSync(directory)
    .filter((file) => SQL_FILE.test(file))
    .sort()
    .map((file) => ({ name: file.replace(SQL_FILE, ""), sql: readFileSync(join(directory, file), "utf8") })));
