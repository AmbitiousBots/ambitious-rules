import { type Migration } from "../domain/migrations.ts";
export declare const loadMigrations: (directory: string) => readonly Migration[];
