export class Failure extends Error {
    errors;
    data;
    constructor(errors, data = {}) {
        super(errors.map(({ code, message }) => `${code}: ${message}`).join(" "));
        this.name = "Failure";
        this.errors = errors;
        this.data = data;
    }
}
export const failure = (code, message, hint, data = {}) => new Failure([{ code, message, hint }], data);
