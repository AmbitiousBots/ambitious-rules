export type LineChange = {
    readonly startLine: number;
    readonly endLine: number;
    readonly before: string;
    readonly after: string;
};
export type LineConflict = {
    readonly startLine: number;
    readonly endLine: number;
    readonly base: string | null;
    readonly current: string;
    readonly published: string;
};
export type LineMerge = {
    readonly merged: string;
    readonly localChangesKept: readonly LineChange[];
    readonly conflicts: readonly LineConflict[];
};
export declare const unknownBaseMerge: (current: string, published: string) => LineMerge;
export declare const mergeLines: (baseText: string, currentText: string, publishedText: string) => LineMerge;
