export type SchemaProblem = {
    readonly pointer: string;
    readonly keyword: string;
    readonly message: string;
};
export declare const schemaProblems: (schema: unknown, value: unknown) => readonly SchemaProblem[];
export declare const describeSchemaProblems: (problems: readonly SchemaProblem[]) => string;
