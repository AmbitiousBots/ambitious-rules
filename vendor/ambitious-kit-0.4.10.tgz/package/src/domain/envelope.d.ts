import { type JsonObject } from "./json.ts";
export type ErrorCode = `E_${string}`;
export type ErrorEntry = {
    readonly code: ErrorCode;
    readonly message: string;
    readonly hint: string;
};
export type Meta = {
    readonly now: string;
    readonly seed: number;
    readonly version: string;
};
export type Identity = {
    readonly schemaVersion: number;
    readonly module: string;
    readonly command: string;
    readonly meta: Meta;
};
type Shared = Identity & {
    readonly data: JsonObject;
};
export type OkEnvelope = Shared & {
    readonly ok: true;
    readonly errors: readonly [];
};
export type ErrEnvelope = Shared & {
    readonly ok: false;
    readonly errors: readonly [ErrorEntry, ...ErrorEntry[]];
};
export type Envelope = OkEnvelope | ErrEnvelope;
export type ExitCode = 0 | 1 | 2;
export declare const INTERNAL_ERROR_CODES: ReadonlySet<string>;
export declare const envelope: {
    ok: ({ schemaVersion, module, command, meta }: Identity, data: JsonObject) => OkEnvelope;
    err: ({ schemaVersion, module, command, meta }: Identity, errors: readonly [ErrorEntry, ...ErrorEntry[]], data?: JsonObject) => ErrEnvelope;
};
export declare const exitCodeOf: (result: Envelope) => ExitCode;
export declare const serialize: (result: Envelope) => string;
export declare const isModuleName: (value: string) => boolean;
export declare const isCommandName: (value: string) => boolean;
export declare const isErrorCode: (value: string) => value is ErrorCode;
export declare const isSemver: (value: string) => boolean;
export declare const envelopeProblems: (value: unknown) => string[];
export {};
