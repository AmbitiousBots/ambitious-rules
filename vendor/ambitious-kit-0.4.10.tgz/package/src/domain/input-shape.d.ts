import { type JsonObject } from "./json.ts";
export declare const FIELD_TYPES: readonly ["string", "number", "integer", "boolean", "object", "array"];
export type FieldType = (typeof FIELD_TYPES)[number];
export type InputField = {
    readonly name: string;
    readonly type: FieldType;
    readonly required: boolean;
};
export type InputShape = {
    readonly fields: readonly InputField[];
    readonly example?: JsonObject;
};
export declare const shapeProblems: (command: string, takesInput: boolean, shape: unknown) => readonly string[];
export declare const listedShape: ({ fields, example }: InputShape) => JsonObject;
