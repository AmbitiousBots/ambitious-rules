import { type InstallOutcome } from "./install.ts";
import { type Fetchers } from "./release.ts";
export type SelfUpdateRequest = {
    readonly home: string;
    readonly runningVersion: string;
    readonly version: string;
    readonly sha256: string;
};
export type SelfUpdateOutcome = InstallOutcome & {
    readonly version: string;
    readonly previousVersion: string;
};
export declare const selfUpdate: ({ home, runningVersion, version, sha256 }: SelfUpdateRequest, fetchers?: Fetchers) => Promise<SelfUpdateOutcome>;
