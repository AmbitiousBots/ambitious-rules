import type { Download } from "./install.ts";
export declare const releaseSource: (from: string) => Download;
