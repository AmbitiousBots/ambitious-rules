import { type InstructionsCatalogue, type InstructionsFinding, type PermissionChange, type SelfApply, type UpgradeAuthority } from "../domain/instructions.ts";
export declare const PROPOSED_INSTRUCTIONS_FILE = "instructions.md";
type Compared = {
    readonly proposed: string;
    readonly diff: readonly string[];
    readonly permissions: PermissionChange | null;
    readonly upgradeOn: UpgradeAuthority;
    readonly selfApply: SelfApply;
};
export type InstructionsReport = ({
    readonly state: "not checked";
    readonly problem: null;
    readonly current: null;
    readonly template: number;
    readonly match: null;
} & Compared) | (InstructionsFinding & Compared);
export declare const proposedInstructionsPath: (home: string) => string;
export declare const checkInstructions: (file: string | null, home: string, catalogue: InstructionsCatalogue) => InstructionsReport;
export {};
