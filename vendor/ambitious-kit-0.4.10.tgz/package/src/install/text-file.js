import { createHash } from "node:crypto";
import { readFileSync, statSync } from "node:fs";
import { failure } from "../domain/failure.js";
import { foldWhitespace } from "../domain/whitespace.js";
import { refuseAgentData } from "../paths/refuse-agent-data.js";
const MAX_BYTES = 256 * 1024;
export const sha256Of = (text) => createHash("sha256").update(text).digest("hex");
export const fingerprintOf = (text) => ({ sha256: sha256Of(text), whitespaceSha256: sha256Of(foldWhitespace(text)) });
export const textOfFile = (file, what, hint) => {
    const path = refuseAgentData(file);
    try {
        if (statSync(path).size > MAX_BYTES)
            throw new Error(`it is larger than ${MAX_BYTES} bytes`);
        return readFileSync(path, "utf8");
    }
    catch (error) {
        throw failure("E_INPUT_SCHEMA", `${what} ${file} could not be read: ${error instanceof Error ? error.message : String(error)}.`, hint);
    }
};
