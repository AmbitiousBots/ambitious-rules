import { type Fingerprint } from "../domain/whitespace.ts";
export declare const sha256Of: (text: string | Uint8Array) => string;
export declare const fingerprintOf: (text: string) => Fingerprint;
export declare const textOfFile: (file: string, what: string, hint: string) => string;
