import { join } from "node:path";
import { classifyInstructions, lineDiff, permissionChange, selfApplyAuthority, upgradeAuthority } from "../domain/instructions.js";
import { foldWhitespace } from "../domain/whitespace.js";
import { fingerprintOf, textOfFile } from "./text-file.js";
export const PROPOSED_INSTRUCTIONS_FILE = "instructions.md";
const HINT = "Write the bot's current instructions, exactly as they are, to a text file outside the bot's private data directory and name that file with --instructions.";
export const proposedInstructionsPath = (home) => join(home, "template", PROPOSED_INSTRUCTIONS_FILE);
export const checkInstructions = (file, home, catalogue) => {
    const proposed = proposedInstructionsPath(home);
    if (file === null)
        return { state: "not checked", problem: null, current: null, template: catalogue.version, match: null, proposed, diff: [], permissions: null, upgradeOn: "the owner's request", selfApply: "not granted" };
    const text = textOfFile(file, "The instructions file", HINT);
    const folded = foldWhitespace(text);
    const finding = classifyInstructions(folded, fingerprintOf(text), catalogue);
    const same = finding.state === "current" || finding.state === "newer";
    return { ...finding, proposed, diff: same ? [] : lineDiff(folded, foldWhitespace(catalogue.text)), permissions: permissionChange(finding, catalogue), upgradeOn: upgradeAuthority(finding, catalogue), selfApply: selfApplyAuthority(finding, folded, catalogue) };
};
