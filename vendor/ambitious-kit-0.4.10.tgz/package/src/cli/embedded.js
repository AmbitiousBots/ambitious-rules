export const embedded = () => {
    if (typeof AMBITIOUS_MODULE === "undefined" ||
        typeof AMBITIOUS_VERSION === "undefined" ||
        typeof AMBITIOUS_MIGRATIONS === "undefined") {
        throw new Error("The module name, version and migrations are embedded when the binary is bundled. Build with bundleOptions() from @ambitious/kit/build/bundle-options and run the file in dist/.");
    }
    return { module: AMBITIOUS_MODULE, version: AMBITIOUS_VERSION, migrations: AMBITIOUS_MIGRATIONS };
};
export const embeddedLock = () => {
    if (typeof AMBITIOUS_LOCK === "undefined") {
        throw new Error("The module pins are embedded when the installer is bundled. Run the file in dist/, or name a lock file with --lock.");
    }
    return AMBITIOUS_LOCK;
};
export const embeddedTemplateFiles = () => {
    if (typeof AMBITIOUS_TEMPLATE_FILES === "undefined") {
        throw new Error("The template fixture files are embedded when the installer is bundled. Run the file in dist/.");
    }
    return AMBITIOUS_TEMPLATE_FILES;
};
export const embeddedInstructions = () => {
    if (typeof AMBITIOUS_INSTRUCTIONS === "undefined") {
        throw new Error("The template's instructions and their known versions are embedded when the installer is bundled. Run the file in dist/.");
    }
    return AMBITIOUS_INSTRUCTIONS;
};
export const embeddedRoutines = () => {
    if (typeof AMBITIOUS_ROUTINES === "undefined") {
        throw new Error("The template's routines and their earlier prompts are embedded when the installer is bundled. Run the file in dist/.");
    }
    return AMBITIOUS_ROUTINES;
};
export const embeddedSkills = () => {
    if (typeof AMBITIOUS_SKILLS === "undefined") {
        throw new Error("The template's skills are embedded when the installer is bundled. Run the file in dist/.");
    }
    return AMBITIOUS_SKILLS;
};
export const embeddedGuides = () => {
    if (typeof AMBITIOUS_GUIDES === "undefined") {
        throw new Error("The template's guides are embedded when the installer is bundled. Run the file in dist/.");
    }
    return AMBITIOUS_GUIDES;
};
