import type { Migration } from "../domain/migrations.ts";
export type Embedded = {
    readonly module: string;
    readonly version: string;
    readonly migrations: readonly Migration[];
};
export declare const embedded: () => Embedded;
export declare const embeddedLock: () => unknown;
export declare const embeddedTemplateFiles: () => unknown;
export declare const embeddedInstructions: () => unknown;
export declare const embeddedRoutines: () => unknown;
export declare const embeddedSkills: () => unknown;
export declare const embeddedGuides: () => unknown;
