export declare const contractMain: (argv: readonly string[]) => number;
