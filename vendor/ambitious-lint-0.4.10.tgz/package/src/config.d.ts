import type { Linter } from "eslint";
export type Options = {
    readonly root: string;
    readonly ignores?: readonly string[];
    readonly defaultExportFiles?: readonly string[];
};
export declare const ambitiousLint: ({ root, ignores, defaultExportFiles }: Options) => Linter.Config[];
