import type { Linter } from "eslint";
export type Ban = {
    readonly message: string;
    readonly allowedIn: readonly string[];
    readonly globals?: readonly string[];
    readonly properties?: readonly (readonly [object: string, property: string])[];
    readonly selectors?: readonly string[];
    readonly imports?: readonly string[];
};
export declare const bans: (defaultExportFiles: readonly string[]) => readonly Ban[];
export declare const restrictions: (active: readonly Ban[]) => Linter.RulesRecord;
